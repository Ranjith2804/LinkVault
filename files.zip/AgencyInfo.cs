namespace Allstar.Core.Models
{
    /// <summary>
    /// One row from the uploaded agency spreadsheet.
    /// AgencyID and Country are carried through for reference/output but are not sent to AIM.
    /// ProducerId / LookupSucceeded are populated after the AIM lookup runs.
    /// </summary>
    public class AgencyInfo
    {
        public string AgencyId { get; set; } = string.Empty;
        public string AgencyName { get; set; } = string.Empty;
        public string Address1 { get; set; } = string.Empty;
        public string? Address2 { get; set; }
        public string City { get; set; } = string.Empty;
        public string StateAbbr { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public string? Country { get; set; }

        // Populated after AimService.GetProducerCode() runs for this row
        public string? ProducerId { get; set; }
        public bool LookupSucceeded { get; set; }
    }
}
