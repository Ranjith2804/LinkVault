using System.Globalization;
using Allstar.Core.Models;
using CsvHelper;
using CsvHelper.Configuration;

namespace Allstar.Core.Services
{
    // NuGet: CsvHelper
    public class CsvAgencyReader : ISpreadsheetReader
    {
        public bool CanRead(string fileName) =>
            fileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);

        public List<AgencyInfo> Read(Stream fileStream)
        {
            using var reader = new StreamReader(fileStream);
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,   // don't blow up on extra/reordered columns
                MissingFieldFound = null, // don't blow up on optional columns being absent
                TrimOptions = TrimOptions.Trim
            });

            csv.Context.RegisterClassMap<AgencyInfoCsvMap>();
            return csv.GetRecords<AgencyInfo>().ToList();
        }
    }

    /// <summary>
    /// Maps the spreadsheet column headers (AgencyID, AgencyName, etc.) onto AgencyInfo,
    /// independent of property naming so header text can differ slightly from the C# names.
    /// </summary>
    public sealed class AgencyInfoCsvMap : ClassMap<AgencyInfo>
    {
        public AgencyInfoCsvMap()
        {
            Map(m => m.AgencyId).Name("AgencyID");
            Map(m => m.AgencyName).Name("AgencyName");
            Map(m => m.Address1).Name("Address1");
            Map(m => m.Address2).Name("Address2").Optional();
            Map(m => m.City).Name("City");
            Map(m => m.StateAbbr).Name("StateAbbr");
            Map(m => m.PostalCode).Name("PostalCode");
            Map(m => m.Country).Name("Country").Optional();
        }
    }
}
