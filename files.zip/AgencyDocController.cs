using Allstar.Core.Models;
using Allstar.Core.Services;
using Microsoft.AspNetCore.Mvc;

namespace Allstar.Core.Controllers
{
    [ApiController]
    [Route("v1/aim/agency")]
    public class AgencyDocController : ControllerBase
    {
        private static readonly string[] AllowedExtensions = { ".csv", ".xlsx" };
        private const int DispatchDelayMs = 2000; // gap between starting one agency's thread and the next

        private readonly SpreadsheetReaderFactory _readerFactory;
        private readonly IAimService _aimService;
        private readonly ISpreadsheetWriter _writer;
        private readonly ILogger<AgencyDocController> _logger;

        public AgencyDocController(
            SpreadsheetReaderFactory readerFactory,
            IAimService aimService,
            ISpreadsheetWriter writer,
            ILogger<AgencyDocController> logger)
        {
            _readerFactory = readerFactory;
            _aimService = aimService;
            _writer = writer;
            _logger = logger;
        }

        /// <summary>
        /// Sync by design: this is a long-running batch job, not a quick request/response call.
        /// Accepts a CSV or Excel upload of agencies, looks each one up in AIM, and returns
        /// the same file with the producer code (and configured AIM fields) added.
        /// </summary>
        [HttpPost("producer/all")]
        public IActionResult UploadAgencyProducers(IFormFile file)
        {
            if (file is null || file.Length == 0)
                return BadRequest("A CSV or Excel file is required.");

            var extension = Path.GetExtension(file.FileName);
            if (!AllowedExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return BadRequest($"Unsupported file type '{extension}'. Only .csv and .xlsx are supported.");

            List<AgencyInfo> agencies;
            try
            {
                var reader = _readerFactory.GetReader(file.FileName);
                using var stream = file.OpenReadStream();
                agencies = reader.Read(stream);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to parse uploaded agency file {FileName}", file.FileName);
                return BadRequest("Could not parse the uploaded file. Check the column headers and try again.");
            }

            if (agencies.Count == 0)
                return BadRequest("No agency rows were found in the uploaded file.");

            _logger.LogInformation(
                "Parsed {Count} agencies from {FileName}. Starting AIM lookups.",
                agencies.Count, file.FileName);

            // This call blocks until every agency's AIM lookup has completed.
            ProcessAgenciesOnDedicatedThreads(agencies);

            var resultBytes = _writer.Write(agencies, extension);
            var outputFileName = $"AgencyProducers_{DateTime.UtcNow:yyyyMMddHHmmss}{extension}";
            var contentType = extension.Equals(".csv", StringComparison.OrdinalIgnoreCase)
                ? "text/csv"
                : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            return File(resultBytes, contentType, outputFileName);
        }

        /// <summary>
        /// Dispatches one thread per agency. Threads are started one at a time, with a fixed
        /// delay between each dispatch, so AIM never receives more than one new request in
        /// quick succession — but each agency still runs on its own thread rather than all
        /// work happening on a single one. Blocks (via Join) until every thread finishes.
        /// </summary>
        private void ProcessAgenciesOnDedicatedThreads(List<AgencyInfo> agencies)
        {
            var threads = new List<Thread>(agencies.Count);

            foreach (var agency in agencies)
            {
                _logger.LogInformation(
                    "Dispatching agency {AgencyId} - {AgencyName} for AIM lookup",
                    agency.AgencyId, agency.AgencyName);

                var thread = new Thread(() => RunSingleAgencyLookup(agency))
                {
                    IsBackground = true,
                    Name = $"AimLookup-{agency.AgencyId}"
                };

                thread.Start();
                threads.Add(thread);

                // Gap before dispatching the NEXT agency's thread — this is what keeps
                // dispatch sequential even though each agency gets its own thread.
                Thread.Sleep(DispatchDelayMs);
            }

            foreach (var thread in threads)
            {
                thread.Join();
            }

            _logger.LogInformation("All {Count} agency lookups completed.", agencies.Count);
        }

        /// <summary>
        /// Runs on its own thread for a single agency. Logs which thread handled which
        /// agency, then either writes the producer code back onto the row (match) or
        /// logs an error (no match / lookup failure).
        /// </summary>
        private void RunSingleAgencyLookup(AgencyInfo agency)
        {
            _logger.LogInformation(
                "Thread {ThreadId} ({ThreadName}) handling agency {AgencyId} - {AgencyName}",
                Thread.CurrentThread.ManagedThreadId,
                Thread.CurrentThread.Name,
                agency.AgencyId,
                agency.AgencyName);

            try
            {
                var result = _aimService.GetProducerCode(agency);

                if (result is { Found: true })
                {
                    agency.ProducerId = result.ProducerId;
                    agency.LookupSucceeded = true;

                    _logger.LogInformation(
                        "AIM match found for agency {AgencyId} - {AgencyName}: {@AimResult}",
                        agency.AgencyId, agency.AgencyName, result);
                }
                else
                {
                    agency.LookupSucceeded = false;

                    _logger.LogError(
                        "No AIM match found for agency {AgencyId} - {AgencyName}",
                        agency.AgencyId, agency.AgencyName);
                }
            }
            catch (Exception ex)
            {
                agency.LookupSucceeded = false;

                _logger.LogError(ex,
                    "AIM lookup threw an exception for agency {AgencyId} - {AgencyName}",
                    agency.AgencyId, agency.AgencyName);
            }
        }
    }
}
