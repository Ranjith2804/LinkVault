using Allstar.Core.Models;

namespace Allstar.Core.Services
{
    // ---- STUBS ----
    // These two are placeholders for the pieces we haven't built yet:
    //   IAimService      -> RSQL query building + the actual AIM HTTP call
    //   ISpreadsheetWriter -> serializing the updated AgencyInfo list back into a file
    // They're defined here only so AgencyDocController compiles on its own.
    // Delete this file once the real implementations exist.

    public interface IAimService
    {
        AimLookupResult GetProducerCode(AgencyInfo agency);
    }

    public class AimLookupResult
    {
        public bool Found { get; set; }
        public string? ProducerId { get; set; }
        public string? Name { get; set; }
        public string? MailAddress1 { get; set; }
        public string? MailCity { get; set; }
        public string? MailState { get; set; }
        // extend as more fields get added to the configured AIM attribute list
    }

    public interface ISpreadsheetWriter
    {
        byte[] Write(List<AgencyInfo> agencies, string fileExtension);
    }
}
