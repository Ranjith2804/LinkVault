using Allstar.Core.Models;
using ClosedXML.Excel;

namespace Allstar.Core.Services
{
    // NuGet: ClosedXML
    public class ExcelAgencyReader : ISpreadsheetReader
    {
        public bool CanRead(string fileName) =>
            fileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase);

        public List<AgencyInfo> Read(Stream fileStream)
        {
            var agencies = new List<AgencyInfo>();

            using var workbook = new XLWorkbook(fileStream);
            var worksheet = workbook.Worksheet(1);

            var lastRowUsed = worksheet.LastRowUsed();
            if (lastRowUsed is null)
                return agencies;

            var columnMap = BuildColumnMap(worksheet.Row(1));
            var lastRow = lastRowUsed.RowNumber();

            for (var rowNum = 2; rowNum <= lastRow; rowNum++)
            {
                var row = worksheet.Row(rowNum);
                if (row.IsEmpty())
                    continue;

                agencies.Add(new AgencyInfo
                {
                    AgencyId = GetCell(row, columnMap, "AgencyID"),
                    AgencyName = GetCell(row, columnMap, "AgencyName"),
                    Address1 = GetCell(row, columnMap, "Address1"),
                    Address2 = GetCell(row, columnMap, "Address2"),
                    City = GetCell(row, columnMap, "City"),
                    StateAbbr = GetCell(row, columnMap, "StateAbbr"),
                    PostalCode = GetCell(row, columnMap, "PostalCode"),
                    Country = GetCell(row, columnMap, "Country")
                });
            }

            return agencies;
        }

        private static Dictionary<string, int> BuildColumnMap(IXLRow headerRow)
        {
            var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var cell in headerRow.CellsUsed())
            {
                var header = cell.GetString().Trim();
                if (!string.IsNullOrEmpty(header))
                    map[header] = cell.Address.ColumnNumber;
            }
            return map;
        }

        private static string GetCell(IXLRow row, Dictionary<string, int> columnMap, string columnName)
        {
            if (!columnMap.TryGetValue(columnName, out var colNum))
                return string.Empty;

            return row.Cell(colNum).GetString().Trim();
        }
    }
}
