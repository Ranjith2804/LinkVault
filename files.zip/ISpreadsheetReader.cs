using Allstar.Core.Models;

namespace Allstar.Core.Services
{
    /// <summary>
    /// Reads an uploaded spreadsheet stream into a collection of AgencyInfo rows.
    /// Implemented once per supported file type (CSV, Excel).
    /// </summary>
    public interface ISpreadsheetReader
    {
        bool CanRead(string fileName);
        List<AgencyInfo> Read(Stream fileStream);
    }
}
