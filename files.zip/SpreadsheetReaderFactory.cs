namespace Allstar.Core.Services
{
    /// <summary>
    /// Picks CsvAgencyReader or ExcelAgencyReader based on the uploaded file's extension.
    /// Register both readers in DI as ISpreadsheetReader, and this factory alongside them.
    /// </summary>
    public class SpreadsheetReaderFactory
    {
        private readonly IEnumerable<ISpreadsheetReader> _readers;

        public SpreadsheetReaderFactory(IEnumerable<ISpreadsheetReader> readers)
        {
            _readers = readers;
        }

        public ISpreadsheetReader GetReader(string fileName)
        {
            var reader = _readers.FirstOrDefault(r => r.CanRead(fileName));

            if (reader is null)
                throw new NotSupportedException($"Unsupported file type for '{fileName}'. Only .csv and .xlsx are supported.");

            return reader;
        }
    }
}
