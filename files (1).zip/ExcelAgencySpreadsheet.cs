using ClosedXML.Excel;
using CRC.OSS.Jobs.Models;

namespace CRC.OSS.Jobs.Services
{
    // NuGet: ClosedXML
    public class ExcelAgencySpreadsheet : ISpreadsheetHandler
    {
        private static readonly string[] OutputHeaders =
        {
            "AgencyID", "AgencyName", "Address1", "Address2",
            "City", "StateAbbr", "PostalCode", "Country", "ProducerCode"
        };

        public bool CanHandle(string fileName) =>
            fileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase);

        public List<AgencyInfo> Read(Stream fileStream)
        {
            var agencies = new List<AgencyInfo>();

            using var workbook = new XLWorkbook(fileStream);
            var worksheet = workbook.Worksheet(1);

            var lastRowUsed = worksheet.LastRowUsed();
            if (lastRowUsed is null)
                return agencies;

            var columnMap = BuildColumnMap(worksheet.Row(1));
            var lastRow = lastRowUsed.RowNumber();

            for (var rowNum = 2; rowNum <= lastRow; rowNum++)
            {
                var row = worksheet.Row(rowNum);
                if (row.IsEmpty())
                    continue;

                agencies.Add(new AgencyInfo
                {
                    AgencyId = GetCell(row, columnMap, "AgencyID"),
                    AgencyName = GetCell(row, columnMap, "AgencyName"),
                    Address1 = GetCell(row, columnMap, "Address1"),
                    Address2 = GetCell(row, columnMap, "Address2"),
                    City = GetCell(row, columnMap, "City"),
                    StateAbbr = GetCell(row, columnMap, "StateAbbr"),
                    PostalCode = GetCell(row, columnMap, "PostalCode"),
                    Country = GetCell(row, columnMap, "Country")
                });
            }

            return agencies;
        }

        public byte[] Write(List<AgencyInfo> agencies)
        {
            using var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("AgencyProducers");

            for (var col = 0; col < OutputHeaders.Length; col++)
                worksheet.Cell(1, col + 1).Value = OutputHeaders[col];

            for (var i = 0; i < agencies.Count; i++)
            {
                var agency = agencies[i];
                var row = i + 2;

                worksheet.Cell(row, 1).Value = agency.AgencyId;
                worksheet.Cell(row, 2).Value = agency.AgencyName;
                worksheet.Cell(row, 3).Value = agency.Address1;
                worksheet.Cell(row, 4).Value = agency.Address2;
                worksheet.Cell(row, 5).Value = agency.City;
                worksheet.Cell(row, 6).Value = agency.StateAbbr;
                worksheet.Cell(row, 7).Value = agency.PostalCode;
                worksheet.Cell(row, 8).Value = agency.Country;
                worksheet.Cell(row, 9).Value = agency.LookupSucceeded ? agency.ProducerId : string.Empty;
            }

            worksheet.Row(1).Style.Font.Bold = true;
            worksheet.Columns().AdjustToContents();

            using var ms = new MemoryStream();
            workbook.SaveAs(ms);
            return ms.ToArray();
        }

        private static Dictionary<string, int> BuildColumnMap(IXLRow headerRow)
        {
            var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var cell in headerRow.CellsUsed())
            {
                var header = cell.GetString().Trim();
                if (!string.IsNullOrEmpty(header))
                    map[header] = cell.Address.ColumnNumber;
            }
            return map;
        }

        private static string GetCell(IXLRow row, Dictionary<string, int> columnMap, string columnName)
        {
            if (!columnMap.TryGetValue(columnName, out var colNum))
                return string.Empty;

            return row.Cell(colNum).GetString().Trim();
        }
    }
}
