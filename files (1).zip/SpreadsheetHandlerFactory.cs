namespace CRC.OSS.Jobs.Services
{
    public class SpreadsheetHandlerFactory
    {
        private readonly IEnumerable<ISpreadsheetHandler> _handlers;

        public SpreadsheetHandlerFactory(IEnumerable<ISpreadsheetHandler> handlers)
        {
            _handlers = handlers;
        }

        public ISpreadsheetHandler GetHandler(string fileName)
        {
            var handler = _handlers.FirstOrDefault(h => h.CanHandle(fileName));

            if (handler is null)
                throw new NotSupportedException($"Unsupported file type for '{fileName}'. Only .csv and .xlsx are supported.");

            return handler;
        }
    }
}
