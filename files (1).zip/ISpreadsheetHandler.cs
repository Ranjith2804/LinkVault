using CRC.OSS.Jobs.Models;

namespace CRC.OSS.Jobs.Services
{
    /// <summary>
    /// One implementation per file format (CSV, Excel). Read and Write live together
    /// so the column list/order can't drift between the two operations.
    /// </summary>
    public interface ISpreadsheetHandler
    {
        bool CanHandle(string fileName);
        List<AgencyInfo> Read(Stream fileStream);
        byte[] Write(List<AgencyInfo> agencies);
    }
}
