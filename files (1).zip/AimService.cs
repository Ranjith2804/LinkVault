using System.Text.Json;
using CRC.OSS.Jobs.Configuration;
using CRC.OSS.Jobs.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CRC.OSS.Jobs.Services
{
    public class AimService : IAimService
    {
        private readonly HttpClient _httpClient;
        private readonly AimOptions _options;
        private readonly ILogger<AimService> _logger;

        public AimService(HttpClient httpClient, IOptions<AimOptions> options, ILogger<AimService> logger)
        {
            _httpClient = httpClient;
            _options = options.Value;
            _logger = logger;
        }

        public async Task<AimLookupResult> GetProducerCodeAsync(AgencyInfo agency, CancellationToken ct)
        {
            var rsql = BuildRsqlQuery(agency);
            var requestUri = $"{_options.BaseUrl}?search={Uri.EscapeDataString(rsql)}";

            HttpResponseMessage response;
            try
            {
                response = await _httpClient.GetAsync(requestUri, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "AIM call failed for agency {AgencyId} - {AgencyName}",
                    agency.AgencyId, agency.AgencyName);
                return new AimLookupResult { Found = false };
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("AIM returned {StatusCode} for agency {AgencyId} - {AgencyName}",
                    response.StatusCode, agency.AgencyId, agency.AgencyName);
                return new AimLookupResult { Found = false };
            }

            var json = await response.Content.ReadAsStringAsync(ct);
            return ParseResponse(json);
        }

        /// <summary>
        /// Built off the spreadsheet-to-AIM mapping table:
        /// AgencyName->name, Address1->mailAddress1, Address2->mailAddress2,
        /// City->mailCity, StateAbbr->mailState, PostalCode->mailZip.
        /// AgencyID and Country have no AIM column, so they're excluded here.
        /// Address2 is only included when present since it's often blank (suite numbers etc.)
        /// and would cause false non-matches otherwise.
        /// </summary>
        private static string BuildRsqlQuery(AgencyInfo agency)
        {
            var clauses = new List<string>
            {
                $"name=={EscapeRsqlValue(agency.AgencyName)}",
                $"mailAddress1=={EscapeRsqlValue(agency.Address1)}"
            };

            if (!string.IsNullOrWhiteSpace(agency.Address2))
                clauses.Add($"mailAddress2=={EscapeRsqlValue(agency.Address2)}");

            clauses.Add($"mailCity=={EscapeRsqlValue(agency.City)}");
            clauses.Add($"mailState=={EscapeRsqlValue(agency.StateAbbr)}");
            clauses.Add($"mailZip=={EscapeRsqlValue(agency.PostalCode)}");
            clauses.Add("activeFlag==\"Y\"");

            return string.Join(";", clauses);
        }

        /// <summary>
        /// Basic RSQL string escaping (backslash then double-quote). Test this against a few
        /// agency names with apostrophes/quotes/ampersands once you're hitting the real AIM
        /// test environment — RSQL implementations vary in exactly what needs escaping.
        /// </summary>
        private static string EscapeRsqlValue(string value)
        {
            var escaped = (value ?? string.Empty)
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"");
            return $"\"{escaped}\"";
        }

        /// <summary>
        /// TODO: confirm the real AIM payload shape once you can hit the test endpoint —
        /// this currently handles either a raw JSON array of producers or a single JSON
        /// object, and takes the first match. Adjust here if AIM wraps results differently
        /// (e.g. { "content": [...] } or { "results": [...] }).
        /// </summary>
        private AimLookupResult ParseResponse(string json)
        {
            using var doc = JsonDocument.Parse(json);
            JsonElement? record = null;

            if (doc.RootElement.ValueKind == JsonValueKind.Array)
            {
                if (doc.RootElement.GetArrayLength() > 0)
                    record = doc.RootElement[0];
            }
            else if (doc.RootElement.ValueKind == JsonValueKind.Object)
            {
                record = doc.RootElement;
            }

            if (record is null)
                return new AimLookupResult { Found = false };

            var fields = new Dictionary<string, string?>();
            foreach (var fieldName in _options.ResponseFields)
            {
                if (record.Value.TryGetProperty(fieldName, out var prop))
                {
                    fields[fieldName] = prop.ValueKind == JsonValueKind.Null
                        ? null
                        : prop.ToString();
                }
            }

            fields.TryGetValue("producerId", out var producerId);

            return new AimLookupResult
            {
                Found = true,
                ProducerId = producerId,
                Fields = fields
            };
        }
    }
}
