using System.Globalization;
using CRC.OSS.Jobs.Models;
using CsvHelper;
using CsvHelper.Configuration;

namespace CRC.OSS.Jobs.Services
{
    // NuGet: CsvHelper
    public class CsvAgencySpreadsheet : ISpreadsheetHandler
    {
        private static readonly string[] OutputHeaders =
        {
            "AgencyID", "AgencyName", "Address1", "Address2",
            "City", "StateAbbr", "PostalCode", "Country", "ProducerCode"
        };

        public bool CanHandle(string fileName) =>
            fileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);

        public List<AgencyInfo> Read(Stream fileStream)
        {
            using var reader = new StreamReader(fileStream);
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,   // don't blow up on extra/reordered columns
                MissingFieldFound = null, // don't blow up on optional columns being absent
                TrimOptions = TrimOptions.Trim
            });

            csv.Context.RegisterClassMap<AgencyInfoCsvMap>();
            return csv.GetRecords<AgencyInfo>().ToList();
        }

        public byte[] Write(List<AgencyInfo> agencies)
        {
            using var ms = new MemoryStream();

            using (var writer = new StreamWriter(ms, leaveOpen: true))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                foreach (var header in OutputHeaders)
                    csv.WriteField(header);
                csv.NextRecord();

                foreach (var agency in agencies)
                {
                    csv.WriteField(agency.AgencyId);
                    csv.WriteField(agency.AgencyName);
                    csv.WriteField(agency.Address1);
                    csv.WriteField(agency.Address2);
                    csv.WriteField(agency.City);
                    csv.WriteField(agency.StateAbbr);
                    csv.WriteField(agency.PostalCode);
                    csv.WriteField(agency.Country);
                    csv.WriteField(agency.LookupSucceeded ? agency.ProducerId : string.Empty);
                    csv.NextRecord();
                }
            }

            return ms.ToArray();
        }
    }

    /// <summary>Maps spreadsheet header names onto AgencyInfo, independent of C# property names.</summary>
    public sealed class AgencyInfoCsvMap : ClassMap<AgencyInfo>
    {
        public AgencyInfoCsvMap()
        {
            Map(m => m.AgencyId).Name("AgencyID");
            Map(m => m.AgencyName).Name("AgencyName");
            Map(m => m.Address1).Name("Address1");
            Map(m => m.Address2).Name("Address2").Optional();
            Map(m => m.City).Name("City");
            Map(m => m.StateAbbr).Name("StateAbbr");
            Map(m => m.PostalCode).Name("PostalCode");
            Map(m => m.Country).Name("Country").Optional();
        }
    }
}
