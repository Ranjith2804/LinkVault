using CRC.OSS.Jobs.Configuration;
using CRC.OSS.Jobs.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CRC.OSS.Jobs.Services
{
    /// <summary>
    /// Runs the AIM lookup for every agency in the collection using a bounded pool of
    /// concurrent lanes (AimOptions.MaxDegreeOfParallelism, default 8) instead of either
    /// fully serial (too slow at 2000 rows) or fully unbounded (bombards AIM).
    /// Each agency, when its turn comes up in a lane, gets processed on its own thread —
    /// logged by thread id — and that lane waits DelayBetweenCallsMs before taking its
    /// next agency off the queue.
    /// </summary>
    public class AgencyProcessingService
    {
        private readonly IAimService _aimService;
        private readonly AimOptions _options;
        private readonly ILogger<AgencyProcessingService> _logger;

        public AgencyProcessingService(IAimService aimService, IOptions<AimOptions> options, ILogger<AgencyProcessingService> logger)
        {
            _aimService = aimService;
            _options = options.Value;
            _logger = logger;
        }

        public async Task ProcessAllAsync(List<AgencyInfo> agencies, CancellationToken ct = default)
        {
            var parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = _options.MaxDegreeOfParallelism,
                CancellationToken = ct
            };

            _logger.LogInformation(
                "Starting AIM lookups for {Count} agencies with {Lanes} concurrent lanes",
                agencies.Count, _options.MaxDegreeOfParallelism);

            await Parallel.ForEachAsync(agencies, parallelOptions, async (agency, token) =>
            {
                await ProcessSingleAgencyAsync(agency, token);
            });

            var successCount = agencies.Count(a => a.LookupSucceeded);
            _logger.LogInformation(
                "Completed AIM lookups for {Count} agencies. {SuccessCount} matched, {FailCount} did not.",
                agencies.Count, successCount, agencies.Count - successCount);
        }

        private async Task ProcessSingleAgencyAsync(AgencyInfo agency, CancellationToken ct)
        {
            _logger.LogInformation(
                "Thread {ThreadId} handling agency {AgencyId} - {AgencyName}",
                Environment.CurrentManagedThreadId, agency.AgencyId, agency.AgencyName);

            try
            {
                var result = await _aimService.GetProducerCodeAsync(agency, ct);

                if (result.Found)
                {
                    agency.ProducerId = result.ProducerId;
                    agency.AimFields = result.Fields;
                    agency.LookupSucceeded = true;

                    _logger.LogInformation(
                        "AIM match found for agency {AgencyId} - {AgencyName}: {@AimFields}",
                        agency.AgencyId, agency.AgencyName, result.Fields);
                }
                else
                {
                    agency.LookupSucceeded = false;

                    _logger.LogError(
                        "No AIM match found for agency {AgencyId} - {AgencyName}",
                        agency.AgencyId, agency.AgencyName);
                }
            }
            catch (Exception ex)
            {
                agency.LookupSucceeded = false;

                _logger.LogError(ex,
                    "AIM lookup threw an exception for agency {AgencyId} - {AgencyName}",
                    agency.AgencyId, agency.AgencyName);
            }

            // Pacing within this lane — this agency's slot in the lane holds for 2s
            // before the lane picks up its next agency off the queue.
            await Task.Delay(_options.DelayBetweenCallsMs, ct);
        }
    }
}
