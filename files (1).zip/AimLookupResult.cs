namespace CRC.OSS.Jobs.Models
{
    /// <summary>
    /// Outcome of a single AIM producer lookup. Fields is config-driven — it holds whatever
    /// attributes are listed in AimOptions.ResponseFields, so adding an attribute to config
    /// is enough to start capturing it, no code change needed here.
    /// </summary>
    public class AimLookupResult
    {
        public bool Found { get; set; }
        public string? ProducerId { get; set; }
        public Dictionary<string, string?> Fields { get; set; } = new();
    }
}
