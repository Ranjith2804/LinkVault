namespace CRC.OSS.Jobs.Models
{
    /// <summary>
    /// One row from the uploaded agency spreadsheet.
    /// AgencyID and Country are carried through for reference/output but are not sent to AIM
    /// (they have no corresponding AIM field per the mapping table).
    /// </summary>
    public class AgencyInfo
    {
        public string AgencyId { get; set; } = string.Empty;
        public string AgencyName { get; set; } = string.Empty;
        public string Address1 { get; set; } = string.Empty;
        public string? Address2 { get; set; }
        public string City { get; set; } = string.Empty;
        public string StateAbbr { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public string? Country { get; set; }

        // Populated after AgencyProcessingService runs the AIM lookup for this row
        public string? ProducerId { get; set; }
        public bool LookupSucceeded { get; set; }

        /// <summary>
        /// Any additional AIM response fields configured in appsettings (beyond producerId),
        /// keyed by AIM field name. Add a field to AimOptions.ResponseFields and it shows up
        /// here automatically — extend the spreadsheet writer if you want it as its own column.
        /// </summary>
        public Dictionary<string, string?> AimFields { get; set; } = new();
    }
}
