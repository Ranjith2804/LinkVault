namespace CRC.OSS.Jobs.Configuration
{
    /// <summary>
    /// Binds to the "AimApi" section of appsettings / local.settings.json.
    /// ResponseFields controls which AIM attributes get pulled out of each response —
    /// add a name here and AimService starts capturing it without any code change.
    /// </summary>
    public class AimOptions
    {
        public const string SectionName = "AimApi";

        public string BaseUrl { get; set; } = string.Empty;

        public List<string> ResponseFields { get; set; } = new();

        /// <summary>Max number of agencies processed concurrently (the 5–10 "lane" pool).</summary>
        public int MaxDegreeOfParallelism { get; set; } = 8;

        /// <summary>Delay (ms) each lane waits between its own successive AIM calls.</summary>
        public int DelayBetweenCallsMs { get; set; } = 2000;
    }
}
