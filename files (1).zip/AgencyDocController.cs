using System.Net;
using CRC.OSS.Jobs.Models;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;

namespace CRC.OSS.Jobs.Controllers
{
    public class AgencyDocController
    {
        private static readonly string[] AllowedExtensions = { ".csv", ".xlsx" };

        private readonly Services.SpreadsheetHandlerFactory _handlerFactory;
        private readonly Services.AgencyProcessingService _processingService;
        private readonly ILogger<AgencyDocController> _logger;

        public AgencyDocController(
            Services.SpreadsheetHandlerFactory handlerFactory,
            Services.AgencyProcessingService processingService,
            ILoggerFactory loggerFactory)
        {
            _handlerFactory = handlerFactory;
            _processingService = processingService;
            _logger = loggerFactory.CreateLogger<AgencyDocController>();
        }

        /// <summary>
        /// Sync by design: the function does not return until every agency in the upload
        /// has been looked up. No queueing, no polling — the response body IS the finished
        /// spreadsheet.
        /// </summary>
        [Function("UploadAgencyProducers")]
        public async Task<HttpResponseData> UploadAgencyProducers(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1/aim/agency/producer/all")]
            HttpRequestData req,
            CancellationToken ct)
        {
            var (fileName, fileBytes) = await ExtractUploadedFileAsync(req, ct);

            if (fileBytes is null || fileBytes.Length == 0)
                return await BuildErrorResponseAsync(req, HttpStatusCode.BadRequest, "A CSV or Excel file is required.");

            var extension = Path.GetExtension(fileName);
            if (!AllowedExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return await BuildErrorResponseAsync(req, HttpStatusCode.BadRequest,
                    $"Unsupported file type '{extension}'. Only .csv and .xlsx are supported.");

            // --- Preprocess: file -> collection ---
            List<AgencyInfo> agencies;
            try
            {
                var handler = _handlerFactory.GetHandler(fileName);
                using var readStream = new MemoryStream(fileBytes);
                agencies = handler.Read(readStream);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to parse uploaded agency file {FileName}", fileName);
                return await BuildErrorResponseAsync(req, HttpStatusCode.BadRequest,
                    "Could not parse the uploaded file. Check the column headers and try again.");
            }

            if (agencies.Count == 0)
                return await BuildErrorResponseAsync(req, HttpStatusCode.BadRequest, "No agency rows were found in the uploaded file.");

            _logger.LogInformation("Parsed {Count} agencies from {FileName}. Starting AIM lookups.", agencies.Count, fileName);

            // --- Process: bounded-concurrency AIM lookups, mutates each AgencyInfo in place ---
            await _processingService.ProcessAllAsync(agencies, ct);

            // --- Postprocess: collection -> file ---
            var writeHandler = _handlerFactory.GetHandler(fileName);
            var resultBytes = writeHandler.Write(agencies);

            var outputFileName = $"AgencyProducers_{DateTime.UtcNow:yyyyMMddHHmmss}{extension}";
            var contentType = extension.Equals(".csv", StringComparison.OrdinalIgnoreCase)
                ? "text/csv"
                : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", contentType);
            response.Headers.Add("Content-Disposition", $"attachment; filename=\"{outputFileName}\"");
            await response.WriteBytesAsync(resultBytes);

            return response;
        }

        /// <summary>
        /// Manually parses the multipart/form-data body to pull out the uploaded file —
        /// isolated-worker Functions don't give you IFormFile the way ASP.NET Core MVC does.
        /// </summary>
        private static async Task<(string FileName, byte[]? Bytes)> ExtractUploadedFileAsync(HttpRequestData req, CancellationToken ct)
        {
            var contentTypeHeader = req.Headers.TryGetValues("Content-Type", out var values)
                ? values.FirstOrDefault()
                : null;

            if (string.IsNullOrWhiteSpace(contentTypeHeader) ||
                !MediaTypeHeaderValue.TryParse(contentTypeHeader, out var mediaType) ||
                string.IsNullOrEmpty(mediaType.Boundary.Value))
            {
                return (string.Empty, null);
            }

            var boundary = HeaderUtilities.RemoveQuotes(mediaType.Boundary.Value).Value;
            var reader = new MultipartReader(boundary, req.Body);

            var section = await reader.ReadNextSectionAsync(ct);
            while (section is not null)
            {
                var contentDisposition = section.GetContentDispositionHeader();
                if (contentDisposition is not null && contentDisposition.IsFileDisposition())
                {
                    var fileName = contentDisposition.FileName.Value ?? "upload";
                    using var ms = new MemoryStream();
                    await section.Body.CopyToAsync(ms, ct);
                    return (fileName, ms.ToArray());
                }

                section = await reader.ReadNextSectionAsync(ct);
            }

            return (string.Empty, null);
        }

        private static async Task<HttpResponseData> BuildErrorResponseAsync(HttpRequestData req, HttpStatusCode statusCode, string message)
        {
            var response = req.CreateResponse(statusCode);
            await response.WriteStringAsync(message);
            return response;
        }
    }
}
