using CRC.OSS.Jobs.Models;

namespace CRC.OSS.Jobs.Services
{
    public interface IAimService
    {
        Task<AimLookupResult> GetProducerCodeAsync(AgencyInfo agency, CancellationToken ct);
    }
}
