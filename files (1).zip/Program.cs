using CRC.OSS.Jobs.Configuration;
using CRC.OSS.Jobs.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices((context, services) =>
    {
        services.Configure<AimOptions>(context.Configuration.GetSection(AimOptions.SectionName));

        services.AddHttpClient<IAimService, AimService>(client =>
        {
            // Full request URL is built per-call in AimService from AimOptions.BaseUrl;
            // this timeout is just a safety net against a hung AIM call inside a lane.
            client.Timeout = TimeSpan.FromSeconds(30);
        });

        services.AddSingleton<ISpreadsheetHandler, CsvAgencySpreadsheet>();
        services.AddSingleton<ISpreadsheetHandler, ExcelAgencySpreadsheet>();
        services.AddSingleton<SpreadsheetHandlerFactory>();
        services.AddSingleton<AgencyProcessingService>();
    })
    .Build();

host.Run();
